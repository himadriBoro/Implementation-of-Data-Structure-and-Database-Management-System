CREATE DATABASE assignment04;
USE assignment04;

CREATE TABLE hss_electives (
    roll_number BIGINT,
    sname CHAR(100) NOT NULL,
    cid VARCHAR(50) NOT NULL,
    cname CHAR(200) NOT NULL,
    PRIMARY KEY (roll_number)
);
LOAD DATA LOCAL INFILE 'C:/Users/user/Downloads/database-31-jan-2022/database-31-jan-2022/HSS_ELECTIVE_ALLOCATION_2018_BATCH.csv' INTO TABLE hss_electives FIELDS TERMINATED BY '#' LINES TERMINATED BY '\n' IGNORE 4 LINES;

INSERT INTO hss_electives(roll_number, sname, cid, cname) VALUES(180101058, "Pranav Gupta", "HS 236", "Sociological Perspectives on Modernity"); /* error code: 1062. duplicate entry '180101058' for key 'hss_electives.PRIMARY'  */
INSERT INTO hss_electives(roll_number, sname, cid, cname) VALUES(null, "Pranav Gupta", "HS 236", "Sociological Perspectives on Modernity");  /* error code:1048. Column 'roll-number' cannot be null because roll_number is primary key */
INSERT INTO hss_electives(roll_number, sname, cid, cname) VALUES(180102158, null, "HS 236", "Economics of Uncertainty and Information");    /* error code: 1048. Column 'sname' cannot be null  */
INSERT INTO hss_electives(roll_number, sname, cid, cname) VALUES(180103158, "Pranav Gupta", null, "Economics of Uncertainty and Information" );  /* error code:1048. Column 'cid' cannot be null   */
INSERT INTO hss_electives(roll_number, sname, cid, cname) VALUES(180104158, "Pranav Gupta", "HS 424", null);/* error code: 1048. Column 'cname' cannot be null  */
SET SQL_SAFE_UPDATES=0;

UPDATE hss_electives 
SET 
    roll_number = NULL
WHERE
    roll_number = 180123047;/* error code:1048. Column 'roll-number' cannot be null because roll_number is primary key */
UPDATE hss_electives 
SET 
    roll_number = 180123045
WHERE
    roll_number = 180123046;/* error code: 1062. duplicate entry '180123045' for key 'hss_electives.PRIMARY'  */
    

UPDATE hss_electives 
SET 
    sname = NULL; /* error code:1048. Column 'sname' cannot be null */
UPDATE hss_electives 
SET 
    cid = NULL
WHERE
    cid = "HS 211";/* error code:1048. Column 'cid' cannot be null */
UPDATE hss_electives 
SET 
    cname = NULL
WHERE
    cname = "HS 245";/* error code:1048. Column 'cname' cannot be null */


DELETE FROM hss_electives 
WHERE
    cid = "HS 225"; 
    SELECT * FROM hss_electives WHERE sname LIKE '%Ajay%';

DELETE FROM hss_electives 
WHERE
    sname LIKE '%AJAY%'; 
 LOAD DATA LOCAL INFILE 'C:/Users/user/Downloads/database-31-jan-2022/database-31-jan-2022/HS225.csv' INTO TABLE hss_electives FIELDS TERMINATED BY '#' LINES TERMINATED BY '\n' IGNORE 0 LINES;
LOAD DATA LOCAL INFILE 'C:/Users/user/Downloads/database-31-jan-2022/database-31-jan-2022/ajay.csv' INTO TABLE hss_electives FIELDS TERMINATED BY '#' LINES TERMINATED BY '\n' IGNORE 0 LINES;
SELECT * FROM hss_electives;
/*TASK 8 -
1 warning is there because  there is a duplicate entry.
*/
ALTER TABLE hss_electives DROP PRIMARY KEY;
INSERT INTO hss_electives(roll_number, sname, cid, cname) VALUES(180123001, "Aditi Bihade", "HSS 225", "Inventing the Truth: The Art and Craft of Autobiography");
ALTER TABLE hss_electives ADD constraint roll_number PRIMARY KEY(roll_number); /* error- roll_number cannot become primary key again because roll_no-180123001 is having double entry already */
INSERT INTO hss_electives(roll_number, sname, cid, cname) VALUES(180123001, "Aditi Bihade", "HS 225", "Inventing the Truth: The Art and Craft of Autobiography");
SELECT 
    *
FROM
    hss_electives;

LOAD DATA LOCAL INFILE 'C:/Users/user/Downloads/database-31-jan-2022/database-31-jan-2022/old-hss-electives-allotment.csv' INTO TABLE HSS_electives FIELDS TERMINATED BY ',' LINES TERMINATED BY '\n' IGNORE 1 LINES;
SELECT DISTINCT
    cid
FROM
    hss_electives;
SELECT 
    cid
FROM
    hss_electives;

SELECT * FROM hss_electives WHERE roll_number LIKE '__101__' OR roll_number LIKE '__123__';
SELECT * FROM hss_electives WHERE roll_number LIKE '__123__' AND cname='Sociological Perspectives on Modernity';
SELECT DISTINCT cid , cname FROM hss_electives;
SELECT cid, cname FROM  hss_electives ORDER BY cname DESC;
SELECT sname FROM hss_electives WHERE cname='Human Resource Management' ORDER BY sname, roll_number;

