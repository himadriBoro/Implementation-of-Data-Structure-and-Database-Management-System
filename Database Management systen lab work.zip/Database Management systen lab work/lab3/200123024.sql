-- q1---
create database assignment05;
use assignment05;
-- q2---
CREATE TABLE course (
    cid VARCHAR(50),
    cname CHAR(100),
    l INT,
    t INT,
    p INT,
    c INT,
    PRIMARY KEY (cid)
);
CREATE TABLE course_coordinator (
    cid VARCHAR(20),
    cstart VARCHAR(20),
    csend VARCHAR(20),
    gsubmission VARCHAR(20),
    coordinator CHAR(100),
    exam_date VARCHAR(50),
    PRIMARY KEY (cid)
);
CREATE TABLE course_eligibility (
    cid VARCHAR(20) NOT NULL,
    program CHAR(100),
    batch_year VARCHAR(20),
    batch_month CHAR(30),
    eligibility CHAR(100)
);
CREATE TABLE course_instructor (
    cid VARCHAR(20),
    instructor CHAR(100)
);
CREATE TABLE faculty (
    dept CHAR(100) ,
    instructor CHAR(100),
    PRIMARY KEY(dept, instructor)
);
-- q3--
 load data local infile 'C:/Users/user/Downloads/database-07-jan-2022/database-07-jan-2022/course.csv' into table course
  fields terminated by '#' lines terminated by '\n';
  
   load data local infile 'C:/users/user/Downloads/database-07-jan-2022/database-07-jan-2022/course_coordinator.csv' into table course_coordinator
  fields terminated by '#' lines terminated by '\n';
  
   load data local infile 'C:/Users/user/Downloads/database-07-jan-2022/database-07-jan-2022/course_eligibility.csv' into table course_eligibility
  fields terminated by '#' lines terminated by '\n';

  load data local infile 'C:/Users/user/Downloads/database-07-jan-2022/database-07-jan-2022/course_instructor.csv' into table course_instructor
  fields terminated by '#' lines terminated by '\n';
  
  load data local infile 'C:/Users/user/Downloads/database-07-jan-2022/database-07-jan-2022/faculty.csv' into table faculty
  fields terminated by '#' lines terminated by '\n';
 -- Q4 ---
 -- q1 --- 
SELECT 
    cname, COUNT(eligibility)
FROM
    course_eligibility
        NATURAL JOIN
    course
GROUP BY cid;
-- Q2 --

CREATE TABLE question2 AS (SELECT cid, cname, instructor FROM
    course
        NATURAL JOIN
    course_instructor
ORDER BY cid);
CREATE TABLE question21 AS (SELECT cid, COUNT(instructor) AS cnt FROM
    question2
GROUP BY cid);
SELECT 
    cid, cname, instructor
FROM
    question2
        NATURAL JOIN
    question21
WHERE
    cnt = 3;
-- q3 ---
SELECT DISTINCT
    cname, dept
FROM
    course
        NATURAL JOIN
    course_instructor
        NATURAL JOIN
    faculty
WHERE
    (cid LIKE '%H'
        AND c <> (2 * l + 2 * t + p) / 2)
        OR (cid NOT LIKE '%H'
        AND c <> (2 * l + 2 * t + p));
-- q4---
SELECT 
    cname, coordinator
FROM
    course AS A,
    course_coordinator AS B
WHERE
    A.cid = B.cid
        AND (coordinator NOT IN (SELECT 
            instructor
        FROM
            course_instructor AS C
        WHERE
            B.cid = C.cid));
-- q5 --
SELECT 
    course.cname, course_coordinator.gsubmission
FROM
    course
        JOIN
    course_coordinator ON course.cid = course_coordinator.cid;
  -- Q6 --
SELECT 
    course.cname, course_coordinator.exam_date
FROM
    course
        JOIN
    course_coordinator ON course.cid = course_coordinator.cid
WHERE
    course.cid NOT LIKE '%H';
    -- q7 ---
CREATE TABLE question7 SELECT cid, COUNT(*) AS no_eligible_program FROM
    course_eligibility
GROUP BY cid;
SELECT 
    cid, cname, instructor
FROM
    course_instructor
        NATURAL JOIN
    course
WHERE
    cid IN (SELECT 
            cid
        FROM
            question7
        WHERE
            no_eligible_program >= 10);
-- q8--
SELECT 
    faculty.instructor, faculty.dept, course_instructor.cid
FROM
    faculty,
    course_instructor
WHERE
    course_instructor.instructor = faculty.instructor;
-- q9 --
SELECT 
    dept, instructor
FROM
    faculty
WHERE
    instructor NOT IN (SELECT 
            instructor
        FROM
            course_instructor);   
    
  