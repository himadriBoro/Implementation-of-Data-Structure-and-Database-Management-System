-- q1---
create database assignment06;
use assignment06;
-- q2---
CREATE TABLE course (
    cid VARCHAR(50),
    cname CHAR(100),
    l INT,
    t INT,
    p INT,
    c INT,
    PRIMARY KEY (cid)
);
CREATE TABLE course_coordinator (
    cid VARCHAR(20),
    cstart VARCHAR(20),
    csend VARCHAR(20),
    gsubmission VARCHAR(20),
    coordinator CHAR(100),
    exam_date VARCHAR(50),
    PRIMARY KEY (cid)
);
CREATE TABLE course_eligibility (
    cid VARCHAR(20) NOT NULL,
    program CHAR(100),
    batch_year VARCHAR(20),
    batch_month CHAR(30),
    eligibility CHAR(100)
);
CREATE TABLE course_instructor (
    cid VARCHAR(20),
    instructor CHAR(100)
);
CREATE TABLE faculty (
    dept CHAR(100),
    instructor CHAR(100),
    PRIMARY KEY (dept , instructor)
);
-- q3--
set global local_infile=true;
 load data local infile 'C:/Users/user/Downloads/database-14-feb-2022/database-14-feb-2022/course.csv' into table course
  fields terminated by '#' lines terminated by '\n';
  
   load data local infile 'C:/Users/user/Downloads/database-14-feb-2022/database-14-feb-2022/course_coordinator.csv' into table course_coordinator
  fields terminated by '#' lines terminated by '\n';
  
   load data local infile 'C:/users/user/Downloads/database-14-feb-2022/database-14-feb-2022/course_eligibility.csv' into table course_eligibility
  fields terminated by '#' lines terminated by '\n';

  load data local infile 'C:/Users/user/Downloads/database-14-feb-2022/database-14-feb-2022/course_instructor.csv' into table course_instructor
  fields terminated by '#' lines terminated by '\n';
  
  load data local infile 'C:/Users/user/Downloads/database-14-feb-2022/database-14-feb-2022/faculty.csv' into table faculty
  fields terminated by '#' lines terminated by '\n';


 
  -- q4.1 ---

CREATE TABLE tem1 AS (SELECT cid, cname FROM
    course);

alter table tem1 add counts int;

CREATE TABLE tem2 AS (SELECT cid, COUNT(*) AS cnt FROM
    course_eligibility
WHERE
    cid IN (SELECT 
            cid
        FROM
            tem1)
GROUP BY cid);

SET SQL_SAFE_UPDATES = 0;

UPDATE tem1
        LEFT OUTER JOIN
    tem2 ON tem1.cid = tem2.cid 
SET 
    tem1.counts =tem2.cnt
WHERE
    tem1.cid = tem2.cid;

SET SQL_SAFE_UPDATES = 1;

SELECT 
    cname, counts
FROM
    tem1;

/* Correlated */

CREATE TABLE tem3 AS (SELECT cid, cname FROM
    course);

alter table tem3 add counts int;

CREATE TABLE tem4 AS (SELECT cid, COUNT(*) AS cnt FROM
    course_eligibility
WHERE
    EXISTS( SELECT 
            *
        FROM
            tem3
        WHERE
            tem3.cid = course_eligibility.cid)
GROUP BY cid);

SET SQL_SAFE_UPDATES = 0;

UPDATE tem3
        LEFT OUTER JOIN
    tem4 ON tem3.cid = tem4.cid 
SET 
    tem3.counts = tem4.cnt
WHERE
    tem3.cid = tem4.cid;

SET SQL_SAFE_UPDATES = 1;

SELECT 
    cname, counts
FROM
    tem3;
 -- 4.2 ---
 

CREATE TABLE tabq1 AS (SELECT cid, cname, COUNT(instructor) AS cnt, instructor FROM
    course
        NATURAL JOIN
    course_instructor
GROUP BY cid);
CREATE TABLE tabq3 AS (SELECT cid, cname, instructor FROM
    tabq1
WHERE
    cnt = (SELECT 
            MAX(cnt)
        FROM
            tabq1));
-- nested q --
SELECT 
    tabq3.cid, tabq3.cname, course_instructor.instructor
FROM
    tabq3,
    course_instructor
WHERE
    tabq3.cid IN (SELECT 
            tabq3.cid
        FROM
            tabq3
        WHERE
            tabq3.cid = course_instructor.cid);
-- correlated q ---
SELECT 
    q1.cid, q1.cname, ci.instructor
FROM
    tabq3 AS q1,
    course_instructor AS ci
WHERE
    EXISTS( SELECT 
            *
        FROM
            course_instructor
        WHERE
            q1.cid = ci.cid);
 
 

 
 -- 4.3 --
SELECT DISTINCT
    cname, dept
FROM
    (SELECT 
        cid, cname, l, t, p, c
    FROM
        course) AS A1,
    (SELECT 
        cid, instructor
    FROM
        course_instructor) AS A2,
    (SELECT 
        dept, instructor
    FROM
        faculty) AS A3
WHERE
    A2.instructor = A3.instructor
        AND A1.cid = A2.cid
        AND ((c <> (2 * l + 2 * t + p)
        AND A1.cid NOT LIKE '%H')
        OR (c <> ((2 * l + 2 * t + p) / 2)
        AND A1.cid LIKE '%H'));

-- correlated q --
SELECT 
    cname, dept
FROM
    course
        NATURAL JOIN
    (course_coordinator AS cc1)
        JOIN
    faculty ON cc1.coordinator = faculty.instructor
WHERE
    EXISTS( SELECT 
            *
        FROM
            course AS C4
        WHERE
            ((C4.c <> (2 * C4.l + 2 * C4.t + C4.p)
                AND C4.cid NOT LIKE '%H')
                OR (C4.c <> (2 * C4.l + 2 * C4.t + C4.p) / 2)
                AND C4.cid LIKE '%H')
                AND C4.cid = cc1.cid);

 
        
-- q4.4 ----        

CREATE TABLE tab2 AS (SELECT cname, cid, coordinator FROM
    course
        NATURAL JOIN
    course_coordinator);
 -- nested ---
SELECT 
    cname, coordinator
FROM
    tab2
WHERE
    (cid , coordinator) NOT IN (SELECT 
            *
        FROM
            course_instructor);
 
 -- correlated --
CREATE TABLE tab02 AS SELECT cname, coordinator FROM
    tab2 AS tab3
WHERE
    NOT EXISTS( SELECT 
            cid, instructor
        FROM
            course_instructor AS A1
        WHERE
            (tab3.cid , tab3.coordinator) = (A1.cid , A1.instructor));
  
  -- q4.5 ---
-- nested q --
SELECT 
    C1.cname, G1.gsubmission
FROM
    course AS C1
        NATURAL JOIN
    course_coordinator AS G1
WHERE
    C1.cid IN (SELECT 
            G2.cid
        FROM
            course_coordinator AS G2);
-- correlated q --
SELECT 
    C1.cname, G1.gsubmission
FROM
    course AS C1
        NATURAL JOIN
    course_coordinator AS G1
WHERE
    EXISTS( SELECT 
            *
        FROM
            course_coordinator AS G2
        WHERE
            C1.cid = G2.cid);


-- q4.6 ---
-- nested q --
SELECT 
    cname, A.exam_date
FROM
    course
        JOIN
    (SELECT 
        cid, gsubmission AS exam_date
    FROM
        course_coordinator) AS A
WHERE
    A.cid = course.cid
        AND course.cid NOT LIKE '%H';
-- correlated q --
SELECT 
    cname, gsubmission
FROM
    course
        JOIN
    course_coordinator AS A ON course.cid = A.cid
WHERE
    EXISTS( SELECT 
            cid
        FROM
            course_coordinator AS A
        WHERE
            A.cid NOT LIKE '%H'
                AND A.cid = course.cid);


-- q4.7 --
-- nested q--
SELECT 
    cid, cname, instructor
FROM
    course
        NATURAL JOIN
    course_instructor
WHERE
    cid IN (SELECT 
            cid
        FROM
            (SELECT 
                cid, COUNT(eligibility) AS cnt
            FROM
                course
            NATURAL JOIN course_eligibility
            GROUP BY cid) AS t1
        WHERE
            cnt >= 10);
-- correlated --
CREATE TABLE temp4 AS (SELECT cid, COUNT(cid) AS cnt FROM
    course_eligibility
GROUP BY cid);
SELECT 
    cid, cname, instructor
FROM
    course_instructor
        NATURAL JOIN
    course AS c
WHERE
    EXISTS( SELECT 
            *
        FROM
            temp4 AS t
        WHERE
            t.cnt >= 10 AND t.cid = c.cid);



-- q4.8 ---
-- nested q --
SELECT DISTINCT
    c1.instructor, d1.dept, c1.cid
FROM
    course_instructor AS c1,
    faculty AS d1
WHERE
    (c1.instructor , d1.dept) IN (SELECT 
            A1.instructor, A1.dept
        FROM
            faculty AS A1
                JOIN
            course_instructor AS B1
        WHERE
            A1.instructor = B1.instructor);
-- correlated --
SELECT 
    c1.instructor, d1.dept, c1.cid
FROM
    course_instructor AS c1,
    faculty AS d1
WHERE
    EXISTS( SELECT 
            *
        FROM
            faculty AS A1
        WHERE
            (A1.instructor = c1.instructor)
                AND (A1.instructor = d1.instructor));
 
 
 
-- q4.9 ---

SELECT 
    instructor, dept
FROM
    faculty
WHERE
    instructor NOT IN (SELECT 
            instructor
        FROM
            course_instructor);
-- correlated q--
SELECT 
    instructor, dept
FROM
    faculty AS FACULTY
WHERE
    NOT EXISTS( SELECT 
            instructor
        FROM
            course_instructor AS INSTRUCTOR
        WHERE
            INSTRUCTOR.instructor = FACULTY.instructor);


 
 -- task 05 --
CREATE TABLE tem7 AS (SELECT cid, cname FROM
    course);

alter table tem7 add counts int;

CREATE TABLE tem6 AS (SELECT cid, COUNT(*) AS cnt FROM
    course_eligibility
WHERE
    cid IN (SELECT 
            cid
        FROM
            tem7)
GROUP BY cid);

SET SQL_SAFE_UPDATES = 0;

UPDATE tem7
        LEFT OUTER JOIN
    tem6 ON tem7.cid = tem6.cid 
SET 
    tem7.counts = tem6.cnt
WHERE
    tem7.cid = tem6.cid;

SET SQL_SAFE_UPDATES = 1;

CREATE VIEW name1 (`course name` , `no of eligible programs`) AS
    SELECT 
        cname, counts
    FROM
        tem7;
SELECT 
    *
FROM
    name1;
    
    
    
 -- 5.2 --
CREATE VIEW name2 AS
    SELECT 
        tabq3.cid, tabq3.cname, course_instructor.instructor
    FROM
        tabq3,
        course_instructor
    WHERE
        tabq3.cid IN (SELECT 
                tabq3.cid
            FROM
                tabq3
            WHERE
                tabq3.cid = course_instructor.cid);
SELECT 
    *
FROM
    name2;
    
    
 -- 5.3 --
CREATE VIEW name3 AS
    SELECT DISTINCT
        cname, dept
    FROM
        (SELECT 
            cid, cname, l, t, p, c
        FROM
            course) AS A1,
        (SELECT 
            cid, instructor
        FROM
            course_instructor) AS A2,
        (SELECT 
            dept, instructor
        FROM
            faculty) AS A3
    WHERE
        A2.instructor = A3.instructor
            AND A1.cid = A2.cid
            AND ((c <> (2 * l + 2 * t + p)
            AND A1.cid NOT LIKE '%H')
            OR (c <> ((2 * l + 2 * t + p) / 2)
            AND A1.cid LIKE '%H'));
SELECT 
    *
FROM
    name3;
    
    
-- 5.4 --
CREATE VIEW name4 AS
    (SELECT 
        cname, cid, coordinator
    FROM
        course
            NATURAL JOIN
        course_coordinator);
SELECT 
    cname, coordinator
FROM
    tab2
WHERE
    (cid , coordinator) NOT IN (SELECT 
            *
        FROM
            course_instructor);
SELECT 
    *
FROM
    name4;
    
    
-- 5.5 --
CREATE VIEW name5 AS
    SELECT 
        C1.cname, G1.gsubmission
    FROM
        course AS C1
            NATURAL JOIN
        course_coordinator AS G1
    WHERE
        C1.cid IN (SELECT 
                G2.cid
            FROM
                course_coordinator AS G2);
SELECT 
    *
FROM
    name5;
    
    
-- 5.6 --
CREATE VIEW name6 AS
    SELECT 
        cname, A.exam_date
    FROM
        course
            JOIN
        (SELECT 
            cid, gsubmission AS exam_date
        FROM
            course_coordinator) AS A
    WHERE
        A.cid = course.cid
            AND course.cid NOT LIKE '%H';
SELECT 
    *
FROM
    name6;
    
    
 -- 5.7 ---
CREATE VIEW name7 AS
    SELECT 
        cid, cname, instructor
    FROM
        course
            NATURAL JOIN
        course_instructor
    WHERE
        cid IN (SELECT 
                cid
            FROM
                (SELECT 
                    cid, COUNT(eligibility) AS cnt
                FROM
                    course
                NATURAL JOIN course_eligibility
                GROUP BY cid) AS t1
            WHERE
                cnt >= 10);
SELECT 
    *
FROM
    name7;
    
    
 -- 5.8 --
CREATE VIEW name8 AS
    SELECT DISTINCT
        c1.instructor, d1.dept, c1.cid
    FROM
        course_instructor AS c1,
        faculty AS d1
    WHERE
        (c1.instructor , d1.dept) IN (SELECT 
                A1.instructor, A1.dept
            FROM
                faculty AS A1
                    JOIN
                course_instructor AS B1
            WHERE
                A1.instructor = B1.instructor);
SELECT 
    *
FROM
    name8;
    
    
 -- 5.9 --
CREATE VIEW name9 AS
    SELECT 
        instructor, dept
    FROM
        faculty
    WHERE
        instructor NOT IN (SELECT 
                instructor
            FROM
                course_instructor);
SELECT 
    *
FROM
    name9;