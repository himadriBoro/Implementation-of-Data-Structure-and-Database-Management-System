-- task1
create database assignment07;
use assignment07;

--  task2
-- 2.1 

delimiter $$
create procedure f1111(IN roll_Number int)
begin
declare var1 int;
set var1 =2000 + roll_Number/10000000;
select var1;
end $$
delimiter ;

call f1111(200123024);

-- 2.2
DELIMITER $$
create procedure f2(IN roll_Number int)
begin
  declare v2 int;
  declare v21 varchar(3);
  set v2 =roll_Number/100000;
  set v2= v2%100;
  set v21 = concat('0',v2);
  select v21;
end $$
DELIMITER ;

call f2(200123024);


-- 2.3 

DELIMITER $$
create procedure f3(in roll_Number int)
begin
  declare var3 int;
  set var3 = (roll_Number/1000)%100;
  select var3;
end $$
DELIMITER ;

call f3(200123024);

-- task3
CREATE TABLE hss_electives (
    roll_number INT PRIMARY KEY,
    sname VARCHAR(50) NOT NULL,
    cid VARCHAR(50) NOT NULL,
    cname VARCHAR(100) NOT NULL
);

-- task4
CREATE TABLE student_details (
    roll_number INT PRIMARY KEY,
    sname VARCHAR(50) NOT NULL,
    joined_year INT NOT NULL,
    joined_program VARCHAR(100) NOT NULL,
    joined_dept VARCHAR(50) NOT NULL
);
 

-- task5
Task : 5
DELIMITER $$
create trigger Insert_details
after insert on hss_electives
for each row
begin
call Joined_Year(new.roll_number,@myvar1);
call Program(new.roll_number,@myvar2);
call Dept(new.roll_number,@myvar3);
if @myvar2 = 1 then
 set @myvar4 = 'B.Tech';
else 
 set @myvar4 = 'B.Des';
end if;

case
when @myvar3 = 1 then
  set @myvar5 = 'CSE';
when @myvar3 = 2 then
  set @myvar5 = 'ECE';
when @myvar3 = 3 then
  set @myvar5 = 'ME';
when @myvar3 = 4 then
  set @myvar5 = 'CE';
when @myvar3 = 5 then
  set @myvar5 = 'DD';
when @myvar3 = 6 then
  set @myvar5 = 'BSBE';
when @myvar3 = 7 then
  set @myvar5 = 'CL';
when @myvar3 = 8 then
  set @myvar5 = 'EEE';
when @myvar3 = 21 then
  set @mymyvar5 = 'EPH';
when @myvar3 = 22 then
  set @myvar5 = 'CST';
else
  set @myvar5 = 'M&C';
end case ; 

insert into student_details values (
new.roll_number,
new.sname,
@myvar1,
@myvar4,
@myvar5);
end $$
DELIMITER ;




-- task6
load data local infile 'C:/Users/user/Downloads/HSS_ELECTIVE_ALLOCATION_2018_BATCH.csv' into table hss_electives fields terminated by '#' lines terminated by '\n' ignore  4 lines;

-- task7
-- 7.2
INSERT INTO hss_electives VALUES(2033300,'himadri','HS 111','Physical health');
INSERT INTO hss_electives VALUES(3045633,'twinkle','HS 991','health and environment');
-- 7.3

INSERT INTO hss_electives VALUES('300','himadri boro','HS 221','Sound Structure of Language and Speech Analysis');
INSERT INTO hss_electives VALUES('30000','twinkle boro','HS 685','Psychology of Health and Adjustment');
-- 7.4

INSERT INTO hss_electives VALUES(30000,'raghiv',NULL,'journey towards iit guwahatti');
INSERT INTO hss_electives VALUES(180101090,'ragiv bhatt','HS 197','journey towards iit Bombay');




-- task8
-- Task 8
DELIMITER $$
CREATE TRIGGER alter_Student_Table
AFTER UPDATE ON hss_electives
FOR EACH ROW
BEGIN  
    UPDATE student_details
        SET roll_number = new.roll_number,
                sname = new.sname,
		joined_year = YearOfJoining(new.roll_number),
			joined_program = programCode(new.roll_number),
		joined_dept = departmentCode(new.roll_number)
WHERE roll_number = old.roll_number;
END 
$$
delimiter;
                      
                      
-- task9

DELIMITER $$
CREATE TRIGGER delete_student_details
before delete on hss_electives
FOR EACH ROW 
BEGIN
	delete from student_details
	WHERE roll_number = old.roll_number;
END $$
DELIMITER ;
DELETE FROM hss_electives 
WHERE
    roll_number = 180101010;
SELECT 
    *
FROM
    hss_electives;
SELECT 
    *
FROM
    student_details;