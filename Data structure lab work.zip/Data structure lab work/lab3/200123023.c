
#include <stdio.h>
#include <stdlib.h>

//Visual studio specific to show colors etc.
#include <iostream>
#include <windows.h>


void printArray(int array[], int a, int b, int step, int div)
{
	HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	if (step == 0)
		printf("\n");
	for (int i = 0; i <= 8; i++) {
		if (a == array[i] || b == array[i]) {
		SetConsoleTextAttribute(hConsole, FOREGROUND_RED);

		}
		else {
		SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE);

		}

	}

}


void swap(int *a, int *b) {
	int t = *a;
	*a = *b;
	*b = t;
}

int partition_pivot_last(int array[], int low, int high, int div) {
	int pivot = array[high];
	int i = (low - 1);
	int step = 0;

	printArray(array, array[low], array[high], 0, div);
	for (int j = low; j < high; j++) {
		if (array[j] < pivot) {
		swap(&array[++i], &array[j]);
		printArray(array, array[i], array[j], ++step, div);
		}
	}

	swap(&array[i + 1], &array[high]);
	printArray(array, array[i + 1], array[high], 99, div);
	return (i + 1);
}

int partition_pivot_first(int array[], int low, int high, int div) {
	int pivot = array[low];
	int i = (low + 1);
	int step = 0;

	printArray(array, array[low], array[high], 0, div);
	for (int j = low + 1; j <= high; j++) {
		if (array[j] < pivot) {
		if (j != i) {
		swap(&array[i], &array[j]);
		printArray(array, array[i], array[j], ++step, div);
		}
		i++;
		}
	}

	swap(&array[i - 1], &array[low]);
	printArray(array, array[i - 1], array[low], 99, div);
	return (i - 1);
}

int partition_pivot_random(int array[], int low, int high, int div) {
	int pivot;
	int n = rand();
	pivot = low + n % (high - low + 1); // Randomizing the pivot
	printArray(array, array[high], array[pivot], 0, div);
	//swap(&array[high], &array[pivot]);
	return partition_pivot_last(array, low, high, div);
}

int partition_pivot_median(int array[], int low, int high, int div) {

	int pivot;
	int mid = (low + high) / 2;
	if (array[mid] < array[low])
		swap(&array[mid], &array[low]);
	if (array[high] < array[low])
		swap(&array[high], &array[low]);
	if (array[high] < array[mid])
		swap(&array[high], &array[mid]);
	swap(&array[mid], &array[high - 1]);

	pivot = array[high - 1];

	//swap(&array[pivot], &array[low]);

	return partition_pivot_last(array, low, high, div);
}

void quickSort(int array[], int low, int high, int div) {
	if (low < high) {
		//int pi = partition_pivot_first(array, low, high, div);
		//int pi = partition_pivot_last(array, low, high, div);
		//int pi = partition_pivot_random(array, low, high, div);
		int pi = partition_pivot_median(array, low, high, div);
		div++;
		// Sort the elements on the left of pivot
		quickSort(array, low, pi - 1, div);

		// Sort the elements on the right of pivot
		quickSort(array, pi + 1, high, div);
	}
}



int main(void) {
	int array[] = { 1,  3,  2,  4,  6,  8,  7,  9,  5 };
	int size = sizeof(array) / sizeof(array[0]);
	for (int i = 0; i < size; i++)

	printf("\n");

	quickSort(array, 0, size - 1, 0);

	printf("\n");
	for (int i = 0; i < size; i++)


	getchar();
	return 0;
}
