//name=Himadri boro
//roll no=200123024
// lab no= 01
// date=6/09/2021
//full question=
//1. Write a program to convert an infix expression to postfix expression and evaluate the postfix expression and prints the value. The given infix ex- pression need not be fully paranthesized. So your program should handle the precedence of operators.
//2. Write a program Tail that takes two command line arguments k and in- put.txt and prints the last k lines of the file input.txt. Use appropriate data structure.




#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>

#define ll long long int

struct stack
{
  char x;
  struct stack *link;
};

struct value
{
  ll value1;
  struct value *next;
};

int isEmpty(struct stack *top)
{
   if(top==NULL)
   {
     return 1;
   }
   else
   {
     return 0;
   }
}

int isEmpty1(struct value *top)
{
   if(top==NULL)
   {
     return 1;
   }
   else
   {
     return 0;
   }
}

char stackTop(struct stack *top)
{
   if(top==NULL)
   return '!';
   return top->x;
}

int operation(char c)
{
  if(c=='+'||c=='-'||c=='*'||c=='/'||c=='^')
  return 1;
  return 0;
}

int prec(char c)
{
   if(c=='+'||c=='-')
   return 1;

   if(c=='*'||c=='/')
   return 2;

   if(c=='^')
   return 3;

   if(c=='!'||c=='(')
   return 0;
}

struct stack * push(struct stack *top,char c)
{
  struct stack *n;
  n=(struct stack *)malloc(sizeof(struct stack));
  n->x=c;
  n->link=top;
  top=n;
  return top;
}

struct value * push1(struct value *top,ll c)
{
  struct value *n;
  n=(struct value *)malloc(sizeof(struct value));
  n->value1=c;
  n->next=top;
  top=n;
  return top;
}

char pop(struct stack **top)
{
   struct stack *n=*top;
   char y;
   (*top)=(*top)->link;
   y=n->x;
   free(n);
   return y;
}

ll pop1(struct value **top)
{
   struct value *n=*top;
   ll y;
   (*top)=(*top)->next;
   y=n->value1;
   free(n);
   return y;
}

char* infixtopostfix(char *infix)
{
   char *prefix;
   int i,j=0;
   char buffer;
   struct stack *top = NULL;
   prefix = (char *)malloc((strlen(infix)+1)*sizeof(char));

   for(i=0;i<strlen(infix);i++)
   {

      if(infix[i]=='(')
      top = push(top,infix[i]);

      else if(infix[i]==')')
      {

	 while(stackTop(top)!='(')
	 {
	    prefix[j] = pop(&top);
	    j++;
	 }

	 buffer = pop(&top);

      }

      else if(!operation(infix[i]))
      {
	  prefix[j] = infix[i];
	  j++;
      }

      else if(operation(infix[i]))
      {
	 if(prec(stackTop(top))<prec(infix[i]))
	 top = push(top,infix[i]);

	 else
	 {
	    while((prec(stackTop(top))>=prec(infix[i]))&&(!isEmpty(top)))
	    {
		prefix[j] = pop(&top);
		j++;
	    }
	    top = push(top,infix[i]);
	 }

      }

   }

   while(!isEmpty(top))
   {
      prefix[j] = pop(&top);
      j++;
   }

   prefix[j] = NULL;

   return prefix;
}

ll operate(char x,int a,int b)
{
  if(x=='+')
  return b+a;

  if(x=='-')
  return b-a;

  if(x=='*')
  return b*a;

  if(x=='/')
  return b/a;

  if(x=='^')
  return pow(b,a);
}

ll eval(char *postfix)
{
  ll a,b,i,temp,len,ans;
  struct value *top1 = NULL;
  len = strlen(postfix);
  for(i=0;i<len;i++)
  {
    if(postfix[i]>='0'&&postfix[i]<='9')
    top1 = push1(top1,postfix[i]-48);
    else
    {
       a = pop1(&top1);
       b = pop1(&top1);
       temp = operate(postfix[i],a,b);
       top1=push1(top1,temp);
    }
 }
 ans = pop1(&top1);
 return ans;
}

int main()
{
    char * infix;
    char * postfix;
    char ch;
    int fixer=0,j=0;
    long long int value;

    printf("Enter infix expression : ");
    fflush(stdin);
    scanf("%[^\n]s",infix);

    printf("\nInfix expression is %s\n", infix);

    postfix = infixtopostfix(infix);

    printf("\nPostfix expression is %s\n",postfix);

    value = eval(postfix);

    printf("Value of expression is : %lld\n",value);

    return 0;
}
