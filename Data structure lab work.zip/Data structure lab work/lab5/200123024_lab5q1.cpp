// ANURAG AHIRWAR
// 200123009
// 13-SEPT-2021
// LAB-05
// QEUSTION 1st..

#include <bits/stdc++.h>
using namespace std;

typedef pair<int, pair<int, int>> pai;

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int n;
    cin >> n;
    int k = -1, l = -1, m = -1, t = -1;

    priority_queue<pai, vector<pai>, greater<pai>> aa;
    priority_queue<pai, vector<pai>, greater<pai>> bb;
    int i = 0;
    while (i < n)
    {
        aa.push(make_pair(i * i * i, make_pair(i, 0)));
        i++;
    }
    int count = 0;
    while (aa.empty() == false)
    {
        pair<int, pair<int, int>> topele = aa.top();
        int i = topele.second.first;
        int j = topele.second.second;
        if (k != j || l != i)
        {
            if (topele.first != t)
            {
                cout << topele.first << " " << i << " " << j << endl;
                count++;
            }
            if (topele.first == m && topele.first != t)
            {
                t = topele.first;
                bb.push(make_pair(m, make_pair(k, l)));
                bb.push(make_pair(t, make_pair(i, j)));
            }
        }
        if (j < n - 1)
        {
            j++;
            aa.push(make_pair(i * i * i + j * j * j, make_pair(i, j)));
        }
        k = topele.second.first;
        l = topele.second.second;
        m = topele.first;
        aa.pop();
    }
    cout << "integers following equation a^3+b^3 = c^3+d^3, are  \n"
         << endl;
    if (bb.empty() == true)
    {
        cout << "NULL" << endl;
    }
    else
        while (bb.empty() == false)
        {
            pair<int, pair<int, int>> equation = bb.top();
            cout << " a = " << equation.second.first << " -- b = " << equation.second.second << "  --  a^3+b^3 = " << equation.first << endl;
            bb.pop();
            equation = bb.top();
            cout << " c = " << equation.second.first << " -- d = " << equation.second.second << "  --  c^3+d^3 = " << equation.first << endl;
            bb.pop();
            cout << "______________________________________________________________________\n"
                 << endl;
        }
    // cout<<count<<endl;
    return 0;
}