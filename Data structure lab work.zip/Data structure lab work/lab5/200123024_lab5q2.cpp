// ANURAG AHIRWAR
// 200123009
// 13-SEPT-2021
// LAB-05
// QEUSTION 2nd


#include <bits/stdc++.h>
using namespace std;

//  a+2b2 = 3c3+4d4
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int a, b, c, d;
    for (int i = 0; i < 100; i++)
    {
        for (int j = 0; j < 100; j++)
        {
            for (int k = 0; k < 100; k++)
            {
                for (int l = 0; l < 100; l++)
                {
                    if (i + 2 * (j * j) == 3 * (pow(k,3)) + 4 * (pow(l,4)))
                    {
                        cout << "a= " << i << " b= " << j << " c= " << k << " d= " << l << endl;
                    }
                }
            }
        }
    }

    return 0;
}
