//Name:Himadri boro
//Roll no-200123024
//Lab no- 09
//Date-25th oct 21
#include <bits/stdc++.h>
using namespace std;
#define ll int
const int N = 1e5+7;
unordered_map<string, char> values;
struct nodetru
{
    char ch;
    node *left;
    node *right;
    node *val;
    node()
    {
        left = nullptr;
        right = nullptr;
        val = nullptr;
        ch = '#';
    }
};
typedef node *ptr;
ptr root = nullptr, current = nullptr;
void encoder(ptr root, string str)
{
    if (root->ch != '*')
    {
        values.insert({str, root->ch});
        return;
    }
    else
    {
        encoder(root->left, str + "0");
        encoder(root->right, str + "1");
    }
}
void preorder_tree(ptr root)
{
    if (root != nullptr)
    {
        cout << root->ch << " ";
        preorder_tree(root->left);
        preorder_tree(root->right);
    }
}
void search(ptr root, char key, string *str)
{
    
    if (root != nullptr)
    {
        char x = '0', y = '1';
        str->push_back(x);
        search(root->left, key, str);
        str->pop_back();
        
        search(root->right, key, str);
        str->push_back(y);
        
    }
}
void inorder_tree(ptr root)
{
    if (root != NULL)
    {
        inorder_tree(root->left);
        cout << root->ch << " ";
        inorder_tree(root->right);
    }
}
string decode_massege(string str)
{
    string ans, temp;
    ans = temp = "";
    temp += string(1, str[0]);
    for (int i = 1; i <= str.length(); i++)
    {
        unordered_map<string, char>::iterator it = values.find(temp);
        if (it != values.end())
        {
            ans += string(1, it->second);
            temp = "";
            if (str.length() == i)
                continue;
        }
        temp += string(1, str[i]);
    }
    return ans;
}
void insert_tree(char ar)
{
    ptr new_ch = new node;
    new_ch->ch = ar;
    if (current == nullptr)
    {
        root = new_ch;
        current = new_ch;
    }
    else if (current->ch == '*')
    {
        current->left = new_ch;
        new_ch->val = current;
        current = current->left;
    }
    else
    {
        if (current->val->right == nullptr)
        {
            current = current->val;
            current->right = new_ch;
            new_ch->val = current;
            current = current->right;
        }
        else
        {
            while (current->val->right != nullptr)
            {
                current = current->val;
            }
            current = current->val;
            current->right = new_ch;
            new_ch->val = current;
            current = current->right;
        }
    }
}
int main()
{
    string beta, alpha;
    vector<char> array;
    cout<<"Enter the preorder traversal of the tree" << endl;
    getline(cin,alpha);
    ll n = alpha.length();
    cout<<"Please enter the compressed message to be decoded" << endl;;
    cin>>beta;
    for (ll i = 0; i < n; i++){
        if (alpha[i] != '*'){
            array.push_back(alpha[i]);
        }
        insert_tree(alpha[i]);
    }
    cout << "The preorder display is " << endl;
    preorder_tree(root);
    cout << "\n\n\n\n\n";
    cout << "The inorder display is" << endl;
    inorder_tree(root);
    cout << "\n\n\n\n\n";
    cout << "\n\nThe character\tencoding\n\n";
    encoder(root, "");
    for (auto count : values)
    {
        cout << count.second << "\new_ch\new_ch\new_ch" << count.first << endl;
    }
    cout<<"The decoded message is" <<endl<<decode_massege(beta);
    return 0;
}