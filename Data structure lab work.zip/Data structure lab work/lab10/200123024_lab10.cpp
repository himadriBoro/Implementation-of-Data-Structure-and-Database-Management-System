// name- ANURAG AHIRWAR
// roll no. 200123009
// lab 10
// 08-nov-2021
// Q1. Write a program to find "Bacon Number" of any Actor.
// Q2. Find the number of actors with Bacon Number i for i ={1,2,3,4....,10}

#include <bits/stdc++.h>
using namespace std;

int main()
{
    freopen("imdb.top250.txt", "r", stdin);
    vector<string> input;
    vector<string> movies;
    vector<string> actors;

    string tempstring;

    while (getline(cin, tempstring))
    {
        input.push_back(tempstring);
    }

    int n = input.size();
    // cout << k;
    int aa = 1, bb = 1;

    map<string, vector<string>> mapping;
    map<string, int> moovv;
    map<string, int> actt;

    freopen("output.txt", "w", stdout);
    string temp;
    for (int i = 0; i < n; i++)
    {
        temp = input[i];
        for (int j = 0; j < temp.size(); j++)
        {
            if (temp[j] != '|')
            {
            }
            else
            {
                string a = temp.substr(0, j);
                // cout<<a<<endl;
                string b = temp.substr(j + 1, temp.size() - j - 1);
                // cout<<b<<endl;
                if (!mapping[b].size())
                {

                    movies.push_back(b);
                    moovv[b] = aa++;
                }
                mapping[b].push_back(a);
                if (!actt[a])
                {
                    actt[a] = bb++;
                    actors.push_back(a);
                }
            }
        }
    }
    vector<int> adjacent[bb + 1];
    map<string, vector<string>>::iterator it;

    for (it = mapping.begin(); it != mapping.end(); it++)
    {
        vector<string> temp = (*it).second;
        for (int i = 0; i < temp.size(); i++)
        {
            for (int j = i + 1; j < temp.size(); j++)
            {
                adjacent[actt[temp[i]]].push_back(actt[temp[j]]);
                adjacent[actt[temp[j]]].push_back(actt[temp[i]]);
            }
        }
    }
    int arr[bb + 1];
    queue<int> store;
    int xx = actt["Kevin Bacon (I)"];

    store.push(xx);

    for (int i = 0; i <= bb; i++)
    {
        arr[i] = -1;
    }
    arr[xx] = 0;

    map<long long int, long long int> answer;
    answer[xx] = 0;

    while (!store.empty())
    {
        int x = store.front();
        // cout<<x<<endl;
        store.pop();
        int i = 0;
        while (i < adjacent[x].size())
        {
            if (arr[adjacent[x][i]] == -1)
            {
                arr[adjacent[x][i]] = arr[x] + 1;
                answer[arr[x] + 1]++;
                // cout << adjacent[x][i] << endl;
                store.push(adjacent[x][i]);
            }
            i++;
        }
    }

    answer[0] = 1;
    int i = 1;
    while (i < bb)
    {
        cout << " BACON NUMBER OF " << actors[i] << " IS ";
        if (arr[i] != -1)
        {
            cout << arr[i] << endl;
        }
        else
        {
            cout << "INFINITY" << endl;
        }
        i++;
    }

    i = 1;
    while (answer[i])
    {
        cout << " NUMBER OF ACTOR WITH BACON NUMBER " << i << " is " << answer[i] << endl;
        bb = bb - answer[i];
        i++;
    }
}