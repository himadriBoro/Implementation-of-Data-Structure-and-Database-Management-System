/*name=himadri boro
roll no=200123024
lab no=1
date=4oct21
full questions-  1. Write a program that takes as input a fully parenthesized, arithmetic ex- pression and converts it to a binary expression tree. Your program should display the tree in the following way and also print the value associated with the root.
Your program should draw the binary tree T by assigning x− and y−coordinates to each node p such that x(p) is the number of nodes preceding p in the preorder traversal of T and y(p) is the depth of p in T. You may then use these values to fill a character matrix and print the tree.
Challenge case: Allow the leaves to store variables of the form x1, x2, x3, and so on, which are initially 0 and which can be updated interactively by your program, with the corresponding update in the printed value of the root of the expression tree.
*/
#include<iostream>
#include <bits/stdc++.h>



using namespace std;


typedef struct node
{
    char data;

    struct node *left, *right;

} * npt;


npt NewNode(char c)
{
    npt n = new node;

    n->data = c;

    n->left = n->right = nullptr;

    return n;
}


npt build(string& P)
{


    stack<npt> stN;


    stack<char> stC;

    npt m0, m1, m2;


    int p[123] = { 0 };

    p['+'] = p['-'] = 1, p['/'] = p['*'] = 2, p['^'] = 3,

    p[')'] = 0;

    for (int i = 0; i < P.length(); i++)
    {
        if (P[i] == '(') {


            stC.push(P[i]);
        }


        else if (isalpha(P[i]))
        {
            m0 = NewNode(P[i]);
            stN.push(m0);
        }
        else if (p[P[i]] > 0)
        {

            while (
                !stC.empty() && stC.top() != '('
                && ((P[i] != '^' && p[stC.top()] >= p[P[i]])
                    || (P[i] == '^'
                        && p[stC.top()] > p[P[i]])))
            {


                m0 = NewNode(stC.top());
                stC.pop();


                m1 = stN.top();
                stN.pop();


                m2 = stN.top();
                stN.pop();

                m0->left = m2;
                m0->right = m1;


                stN.push(m0);
            }


            stC.push(P[i]);
        }
        else if (P[i] == ')') {
            while (!stC.empty() && stC.top() != '(')
            {
                m0 = NewNode(stC.top());
                stC.pop();
                m1 = stN.top();
                stN.pop();
                m2 = stN.top();
                stN.pop();
                m0->left = m2;
                m0->right = m1;
                stN.push(m0);
            }
            stC.pop();
        }
    }
    m0 = stN.top();
    return m0;
}


void postorder(npt root)
{
    if (root)
    {
        postorder(root->left);
        postorder(root->right);
        cout << root->data;
    }
}



int main()
{
    string P = "(p^q^(r/s&t-u)^(x*y-m*n))";
    P = "(" + P;
    P += ")";
    npt root = build(P);


    postorder(root);

    return 0;
}
