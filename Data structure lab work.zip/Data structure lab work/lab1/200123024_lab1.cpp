#include <bits/stdc++.h>
#include <chrono>
using namespace std::chrono;
using namespace std;
//// FUNCTION FOR REVERSE AN ARRAY ///
void reverse(int arr[], int n)
{
    for (int first = 0, last = n - 1; first < last; first++, last--)
    {
        swap(arr[first], arr[last]);
    }
}
// FUNCTION FOR BUBBLE SORT
void bubbleSort(int arr[], int n)
{
    int i, j;
    for (i = 0; i < n - 1; i++)

    {
        for (j = 0; j < n - i - 1; j++)
        {
            if (arr[j] > arr[j + 1])
            {
                swap(arr[j], arr[j + 1]);
            }
        }
    }
}
// FUNCTION FOR SELECTION SORT

void selectionSort(int arr[], int n)
{
    int i, j, min_idx;

    for (i = 0; i < n - 1; i++)
    {

        min_idx = i;
        {
            for (j = i + 1; j < n; j++)
            {
                if (arr[j] < arr[min_idx])
                {
                    min_idx = j;
                }
            }
        }

        swap(arr[min_idx], arr[i]);
    }
}
// FUNCTION FOR INSERTION SORT

void insertionSort(int arr[], int n)
{
    int i, key, j;
    for (i = 1; i < n; i++)
    {
        key = arr[i];
        j = i - 1;

        while (j >= 0 && arr[j] > key)
        {
            arr[j + 1] = arr[j];
            j = j - 1;
        }
        arr[j + 1] = key;
    }
}
// FUNCTION TO CALCULATE RUNTIME OF BUBBLE SORT

void timeforbubblesort(int arr[], int n)
{
    auto start = high_resolution_clock::now();
    bubbleSort(arr, n);
    auto stop = high_resolution_clock::now();
    auto duration = duration_cast<milliseconds>(stop - start);
    cout << "TIME TAKEN BY BUBBLESORT is -: " << duration.count() << " milliseconds" << endl;
}
// FUNCTION TO CALCULATE RUNTIME OF INSERTION SORT

void timeforinsertionsort(int arr[], int n)
{
    auto start = high_resolution_clock::now();
    insertionSort(arr, n);
    auto stop = high_resolution_clock::now();
    auto duration = duration_cast<milliseconds>(stop - start);
    cout << "TIME TAKEN BY INSERTIONSORT is -: " << duration.count() << " milliseconds" << endl;
}
// FUNCTION TO CALCULATE RUNTIME OF INSERTION SORT

void timeforselectionsort(int arr[], int n)
{
    auto start = high_resolution_clock::now();
    selectionSort(arr, n);
    auto stop = high_resolution_clock::now();
    auto duration = duration_cast<milliseconds>(stop - start);
    cout << "TIME TAKEN BY SELECTIONSORT is -: " << duration.count() << " milliseconds" << endl;
}

int main()
{

    int n = 10;
    while (n <= 100000)
    {

        int arr[n], bub[n], ins[n], sel[n];
        srand(time(0));
        for (int i = 0; i < n; i++)
        {
            int16_t a = rand();
            arr[i] = a;
            bub[i] = a;
            ins[i] = a;
            sel[i] = a;
        }
        cout<<"--------------------------------------------------------------------------------------------------\n";
        cout << "##########  FOR N = " << n << " cases  ##########\n";
        //task 1
        cout << "********* RANDOM ENTRIES **********\n\n";

        timeforinsertionsort(ins, n);
        timeforbubblesort(bub, n);
        timeforselectionsort(sel, n);
        //now our ins , bub and , sel array are sorted so to calculate runtime for sorted entries, I called the funtion again//
        //task 2

        cout << "\n********* SORTED ENTRIES **********\n\n";
        timeforinsertionsort(ins, n);
        timeforbubblesort(bub, n);
        timeforselectionsort(sel, n);

        //our ins, bub and sel are still sorted so now I called reverse funtion to convert sorted arrays into reversly sorted array//

        reverse(ins, n);
        reverse(bub, n);
        reverse(sel, n);

        // now ins ,bub and sel are reversely sorted so to calculate runtime for reversely sorted entries, I called the funtion again//
        //task 3
        cout << "\n********* REVERSELY SORTED ENTRIES **********\n\n";
        timeforinsertionsort(ins, n);
        timeforbubblesort(bub, n);
        timeforselectionsort(sel, n);

        cout << endl;
        n = n * 10;
    }
    return 0;
}