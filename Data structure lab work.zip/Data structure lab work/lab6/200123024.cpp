/*name=himadri boro
roll no=200123024
lab no=1
date=28sept21
full questions-
1. Implement the hash table-based solution to the 2-SUM problem discussed in the class. Use the division method for your hash function and resolve the collision by linear probing.
Test case: This file describes an array with 9 integers. For how many target values t in the interval [3, 10] are there distinct numbers x, y in the input array such that x + y = t? (Answer: 8)
Challenge data set: This file contains one million integers, both positive and negative (possibly with repetitions!), with the ith row specifying the ith entry of the input array. For how many target values t in the interval [−10000, 10000] are there distinct numbers x, y in the input array such that x + y = t?

*/

#include<iostream>
#include<bits/stdc++.h>


using namespace std;

int printPairs(long long int data[] , long long int arr_size,long long int sum )
{
    unordered_set<int> s;
    for (int j = 0; j < arr_size; j++)
    {
        int k = sum - data[j];

        if (s.find(k)!= s.end())

            return 1;

        s.insert(data[j]);
    }
    return 0;
}






void input_data1(long long int data[])
{
    long long int n = 0;
    int num;

    ifstream File;
    File.open("test.txt2");
    while (!File.eof())
    {
        File >> data[n];
        n++;
    }

    File.close();
}



int main()
{    ios_base::sync_with_stdio(false);
     cin.tie(NULL);
    long long int n;

    cout<<" size of the array :"<<"\n";

    cin >> n;
    long long int arr[n];

    input_data1(arr);
    long long int upperBound;

    long long int lowerBound;

    cout<<" upper bound of given limit:"<<"\n";

    cin >>upperBound;
    cout<<" lower bound of given limit :"<<"\n";
    cin>>lowerBound;

    long long int count = 0;
    while (upperBound >= lowerBound)
    {

        long long int a = lowerBound;


        if (printPairs(arr, n, a))
        {
            count++;
        };

        lowerBound++;
    }
    cout << count;

    return 0;
}
