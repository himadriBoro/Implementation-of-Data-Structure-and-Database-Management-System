
#include<iostream>
#include<bits/stdc++.h>



using namespace std;




int mergesorting(int value[], int temp[], int low, int high);







int merging(int value[], int temp[], int low, int mid,
            int high);







int mergeSort_inversion(int value[], int size)
{
    int temp[size];
    return mergesorting(value, temp, 0, size - 1);
}







int mergesorting(int value[], int temp[], int low, int high)
{
   int mid, number_inversion = 0;







    if (high > low)
    {







        mid = (high + low) / 2;







        number_inversion += mergesorting(value, temp, low, mid);
        number_inversion += mergesorting(value, temp, mid + 1, high);







        number_inversion += merging(value, temp, low, mid + 1, high);
    }
    return number_inversion;
}







int merging(int value[], int temp[], int low, int mid,
            int high)
{
    int i, j, k;
    int number_inversion = 0;







    i = low;
    j = mid;
    k = low;
    while ((i <= mid - 1) && (j <= high))
    {
        if (value[i] <= value[j])
        {
            temp[k++] = value[i++];
        }
        else
        {
            temp[k++] = value[j++];







            number_inversion = number_inversion + (mid - i);
        }
    }







    while (i <= mid - 1)
        temp[k++] = value[i++];







    while (j <= high)
        temp[k++] = value[j++];







    for (i = low; i <= high; i++)
        value[i] = temp[i];







    return number_inversion;
}
void data1(int value[])
{
    int n = 0;
    int number;







    ifstream File;







    File.open("tstcase1.txt");
    while (!File.eof())
    {
        File >> value[n];
        n++;
    }







    File.close();
}
void data2(int value[])
{
    int n = 0;
    int number;







    ifstream File;







    File.open("tstcase2.txt");
    while (!File.eof())
    {
        File >> value[n];
        n++;
    }







    File.close();
}
int size1()
{
    int m = 0;
    int number;
    int array[100000];







    ifstream File;
    File.open("tstcase1.txt");
    while (!File.eof())
    {
        File >> array[m];
        m++;
    }







    File.close();
    return m;
}
int size2()
{
    int n = 0;
    int number;







    int array[100000];







    ifstream File;







    File.open("tstcase2.txt");
    while (!File.eof())
    {
        File >> array[n];
        n++;
    }







    File.close();
    return n;
}







int main()
{








    int value[100000], valuesize = size1() - 1;
    data1(value);
    int result = mergeSort_inversion(value, valuesize);







    cout << "  inversions for data in testcase1 are " << result << endl;








    sort(value, value + valuesize);
    result = mergeSort_inversion(value, valuesize);







    cout << "  inversions for sorted data in testcase1 are " << result << endl;







    sort(value, value + valuesize, greater<int>());
    result = mergeSort_inversion(value, valuesize);







    cout << "  inversions for reverse sorted data in testcase1 are " << result << endl;







    data2(value);
    valuesize = size2() - 1;
    result = mergeSort_inversion(value, valuesize);
    cout << "  inversions for data in testcase2 are " << result << endl;







    sort(value, value + valuesize);
    result = mergeSort_inversion(value, valuesize);
    cout << "  inversions for sorted data in testcase2 are " << result << endl;







    sort(value, value + valuesize, greater<int>());
    result = mergeSort_inversion(value, valuesize);
    cout << "  inversions for reverse sorted data in testcase2 are " << result << endl;







    return 0;
}
