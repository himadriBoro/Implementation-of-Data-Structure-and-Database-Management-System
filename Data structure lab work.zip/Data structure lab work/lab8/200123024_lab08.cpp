#include <iostream>
using namespace std;

struct node
{
    int data;
    node *left;
    node *mid;
    node *right;
    node *par;

    node(int value)
    {
        data = value;
        left = NULL;
        mid = NULL;
        right = NULL;
        par = NULL;
    }
};

bool search(node *root, int value)
{
    if (root == NULL)
    {
        return false;
    }
    if (root->data == value)
    {
        return true;
    }
    if (root->right == NULL && root->left == NULL)
    {
        return false;
    }
    if (value <= root->left->data)
    {
        search(root->left, value);
    }
    else if (root->mid != NULL && value > root->left->data && value <= root->mid->data)
    {
        search(root->mid, value);
    }
    else
        search(root->right, value);
}

int main()
{
    node *root = new node(12);
    root->left = new node(6);
    root->left->par = root;
    root->mid = new node(8);
    root->mid->par = root;
    root->right = new node(12);
    root->right->par = root;
    root->left->left = new node(1);
    root->left->left->par = root->left;
    root->left->mid = new node(5);
    root->left->mid->par = root->left;
    root->left->right = new node(6);
    root->left->right->par = root->left;
    root->mid->left = new node(7);
    root->mid->left->par = root->mid;
    root->mid->right = new node(8);
    root->mid->right->par = root->mid;
    root->right->left = new node(9);
    root->right->left->par = root->right;
    root->right->right = new node(12);
    root->right->right->par = root->right;
    int n;
    cin >> n;
    if (search(root, n))
        cout << "Key is present" << endl;
    else
        cout << "Key is not present" << endl;
}